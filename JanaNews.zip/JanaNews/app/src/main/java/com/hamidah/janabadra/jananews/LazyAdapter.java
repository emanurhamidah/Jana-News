package com.hamidah.janabadra.jananews;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by Hamidah on 03/06/2017.
 */

class LazyAdapter extends BaseAdapter {
    private Activity activity;
    private ArrayList<HashMap<String, String>> data;
    private static LayoutInflater inflater = null;
    //  public ImageLoader1 imageLoader;
    public LazyAdapter(Activity a, ArrayList<HashMap<String, String>> d)
    {
        activity = a;

        data = d;
        inflater = (LayoutInflater) activity
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        //ImageLoader1 imageLoader = new ImageLoader1(activity.getApplicationContext());
    }

    public int getCount() {
        return data.size();
    }
    public Object getItem(int position) {
        return position;
    }
    public long getItemId(int position) {
        return position;
    }
    public View getView(int position, View convertView, ViewGroup parent) {
        View vi = convertView;
        if (convertView == null)
            vi = inflater.inflate(R.layout.list_row, null);
            TextView id_berita = (TextView) vi.findViewById(R.id.kode);
            TextView judul = (TextView) vi.findViewById(R.id.judul);
            ImageView thumb_image = (ImageView) vi.findViewById(R.id.gambar);

            HashMap<String, String> daftar_berita = new HashMap<String, String>();
            daftar_berita = data.get(position);

            id_berita.setText(daftar_berita.get(BeritaUtama.TAG_ID));
            judul.setText(daftar_berita.get(BeritaUtama.TAG_JUDUL));

            //ImageLoader1 imageLoader;
            //imageLoader.DisplayImage(daftar_berita.get(BeritaUtama.TAG_GAMBAR),thumb_image);
            Picasso.with(activity.getApplicationContext())
                //.load("http://sapi.ijoal.com/img/berita/pekan kreatif mhs ti.png")
                .load(daftar_berita.get(BeritaUtama.TAG_GAMBAR))
                    .resize(230,230)
                    .centerCrop()
                .error(R.drawable.no_image)
                .into(thumb_image);

        return vi;
    }
}
