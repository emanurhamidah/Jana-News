package com.hamidah.janabadra.jananews;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import org.apache.http.NameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by Hamidah on 04/06/2017.
 */

public class BeritaUtama extends AppCompatActivity {

    private ProgressDialog pDialog;
    JSONParser jParser = new JSONParser();
    ArrayList<HashMap<String, String>> DaftarBerita = new ArrayList<HashMap<String, String>>();
    private static String url_berita = "http://sapi.ijoal.com/berita.php";
    public static final String TAG_ID = "id";
    public static final String TAG_JUDUL = "judul";
    public static final String TAG_GAMBAR = "gambar";
    JSONArray string_json = null;
    ListView list;
    LazyAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.berita_utama);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Tugas Akhir Pemrograman Mobile oleh Bapak Ryan Ari Setyawan, S.Kom.,M,Eng.", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        DaftarBerita = new ArrayList<HashMap<String, String>>();
        new AmbilData().execute();
        list = (ListView) findViewById(R.id.list);
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                HashMap<String, String> map = DaftarBerita.get(position);
                // Starting new intent
                Intent in = new Intent(getApplicationContext(), DetailBerita.class);
                in.putExtra(TAG_ID, map.get(TAG_ID));
                in.putExtra(TAG_GAMBAR, map.get(TAG_GAMBAR));
                startActivity(in);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_berita_utama, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_share) {
           shareIt();
        }

        return super.onOptionsItemSelected(item);
    }

    public void SetListViewAdapter(ArrayList<HashMap<String,
            String>> berita) {
        adapter = new LazyAdapter(this, berita);
        list.setAdapter(adapter);
    }

    class AmbilData extends AsyncTask<String, String, String> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pDialog = new ProgressDialog(BeritaUtama.this);
            pDialog.setMessage("Mohon tunggu...");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(false);
            pDialog.show();
        }
        protected String doInBackground(String... args) {
            List<NameValuePair> params = new ArrayList<NameValuePair>();

            JSONObject json = jParser.makeHttpRequest(url_berita, "GET", params);
            Log.i("Ini nilai json ", ">" + json);
            if (json!=null){
                try {
                    string_json = json.getJSONArray("berita");
                    for (int i = 0; i < string_json.length(); i++) {
                        JSONObject c = string_json.getJSONObject(i);
                        String id_berita = c.getString(TAG_ID);
                        String judul = c.getString(TAG_JUDUL);
                        String link_image = c.getString(TAG_GAMBAR);
                        HashMap<String, String> map = new HashMap<String, String>();
                        map.put(TAG_ID, id_berita);
                        map.put(TAG_JUDUL, judul);
                        map.put(TAG_GAMBAR, link_image);
                        DaftarBerita.add(map);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }else{
                Log.i("Ini nilai json ", ">" + json);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(getApplicationContext(),
                                "Tidak terhubung dengan internet. Check Your Connection",
                                Toast.LENGTH_LONG).show();
                    }
                });
            }
            return null;
        }
        protected void onPostExecute(String file_url) {
            pDialog.dismiss();
            runOnUiThread(new Runnable() {
                public void run() {
                    SetListViewAdapter(DaftarBerita);
                }
            });
        }
    }
    public void shareIt() {
//sharing implementation here
        Intent sharingIntent = new Intent(android.content.Intent.ACTION_SEND);
        sharingIntent.setType("text/plain");
        sharingIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "JANA NEWS (Berita Tentang Acara di Janabadra)");
        sharingIntent.putExtra(android.content.Intent.EXTRA_TEXT, "Untuk mendapatkan informasi lengkap mengenai acara yang dilaksanakan oleh Universitas Janabadra, silahkan download dan pasang JANA NEWS di Android anda. " +
                "https://sites.google.com/a/student.janabadra.ac.id/ema-nur-hamidah/jana-news/jana%20news.apk?attredirects=0&d=1");
        startActivity(Intent.createChooser(sharingIntent, "Share via"));
    }
}
